///////////////////////////////////////////////////////////////////////////////
// File:	StdAfx.cpp
// SDK:		GameSpy Peer SDK
//
// Copyright Notice: This file is part of the GameSpy SDK designed and 
// developed by GameSpy Industries. Copyright (c) 2009 GameSpy Industries, Inc.
// ------------------------------------
// Source file that includes just the standard includes.
//	PeerLobby.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



