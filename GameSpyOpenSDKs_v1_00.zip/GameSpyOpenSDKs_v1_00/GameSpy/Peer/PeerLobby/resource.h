///////////////////////////////////////////////////////////////////////////////
// File:	Resource.h
// SDK:		GameSpy Peer SDK
//
// Copyright Notice: This file is part of the GameSpy SDK designed and 
// developed by GameSpy Industries. Copyright (c) 2009 GameSpy Industries, Inc.

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PeerLobby.rc
//
#define IDD_PEERLOBBY_DIALOG            102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDD_TITLE_PAGE                  106
#define IDD_CONNECT_PAGE                107
#define IDD_GROUP_PAGE                  108
#define IDD_CREATE_PAGE                 109
#define IDD_STAGING_PAGE                110
#define IDR_MAINFRAME                   128
#define IDI_YELLOW_SMILEY               130
#define IDI_RED_SMILEY                  131
#define IDI_RUNNING_GAME                132
#define IDI_STAGING_ROOM                133
#define IDI_GREEN_SMILEY                134
#define IDC_NICK                        1000
#define IDC_NAME                        1001
#define IDC_MAX_PLAYERS                 1002
#define IDC_CREATE_GAME                 1004
#define IDC_JOIN_GAME                   1005
#define IDC_GAMES                       1006
#define IDC_CHAT_WINDOW                 1007
#define IDC_PLAYERS                     1008
#define IDC_MESSAGE                     1009
#define IDC_NOT_READY                   1017
#define IDC_READY                       1018
#define IDC_CREATE                      1020
#define IDC_TITLE                       1021
#define IDC_KEY                         1022
#define IDC_GROUPS                      1029
#define IDC_GROUP_ROOMS                 1030
#define IDC_PROGRESS                    10126

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1031
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
