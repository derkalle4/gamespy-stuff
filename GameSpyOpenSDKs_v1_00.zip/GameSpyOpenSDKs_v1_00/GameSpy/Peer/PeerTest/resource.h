///////////////////////////////////////////////////////////////////////////////
// File:	Resource.h
// SDK:		GameSpy Peer SDK
//
// Copyright (c) IGN Entertainment, Inc.  All rights reserved.  
// This software is made available only pursuant to certain license terms offered
// by IGN or its subsidiary GameSpy Industries, Inc.  Unlicensed use or use in a 
// manner not expressly authorized by IGN or GameSpy is prohibited.

#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PEERTEST_DIALOG             102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDC_BUTTON1                     1000
#define IDC_BUTTON2                     1001
#define IDC_BUTTON3                     1002
#define IDC_BUTTON4                     1003
#define IDC_BUTTON5                     1004
#define IDC_BUTTON6                     1005
#define IDC_BUTTON7                     1006
#define IDC_BUTTON8                     1007
#define IDC_BLOCKING                    1008
#define IDC_BUTTON21                    1009
#define IDC_BUTTON9                     1010
#define IDC_BUTTON10                    1011
#define IDC_QUIET                       1012
#define IDC_RADIO2                      1013
#define IDC_BUTTON36                    1013
#define IDC_RADIO3                      1014
#define IDC_BUTTON49                    1014
#define IDC_RADIO4                      1015
#define IDC_BUTTON50                    1015
#define IDC_OTHER                       1016
#define IDC_BUTTON11                    1017
#define IDC_LIST                        1018
#define IDC_TOTAL                       1019
#define IDC_NICK                        1020
#define IDC_CHANNEL                     1021
#define IDC_EMAIL                       1021
#define IDC_BUTTON12                    1022
#define IDC_BUTTON14                    1023
#define IDC_CHECK1                      1024
#define IDC_BUTTON15                    1025
#define IDC_ROOMS                       1026
#define IDC_BUTTON13                    1027
#define IDC_MESSAGE                     1028
#define IDC_PLAYERS_BOX                 1029
#define IDC_ROOMS_BOX                   1030
#define IDC_BUTTON16                    1031
#define IDC_CHAT_LIST                   1032
#define IDC_TITLE_PLAYERS               1033
#define IDC_PLAYERS_BOX2                1034
#define IDC_PING_HISTORY                1035
#define IDC_EDIT1                       1036
#define IDC_EDIT2                       1037
#define IDC_LOGIN_PASSWORD              1037
#define IDC_EDIT3                       1038
#define IDC_NAMESPACE                   1038
#define IDC_EDIT4                       1039
#define IDC_AUTH_TOKEN                  1039
#define IDC_EDIT5                       1040
#define IDC_PARTNER_CHALLENGE           1040
#define IDC_EDIT6                       1041
#define IDC_EDIT7                       1042
#define IDC_BUTTON37                    1043
#define IDC_RAW                         1044
#define IDC_BUTTON17                    1045
#define IDC_BUTTON18                    1046
#define IDC_PLAYERS_BOX3                1047
#define IDC_BUTTON20                    1048
#define IDC_TITLE                       1049
#define IDC_BUTTON22                    1050
#define IDC_BUTTON23                    1051
#define IDC_BUTTON32                    1052
#define IDC_BUTTON25                    1053
#define IDC_BUTTON26                    1054
#define IDC_BUTTON27                    1055
#define IDC_BUTTON28                    1056
#define IDC_BUTTON29                    1057
#define IDC_BUTTON30                    1058
#define IDC_PROGRESS                    1059
#define IDC_BUTTON33                    1060
#define IDC_BUTTON34                    1061
#define IDC_BUTTON35                    1062
#define IDC_BUTTON38                    1063
#define IDC_KEY_TYPE                    1064
#define IDC_RADIO5                      1065
#define IDC_BUTTON39                    1066
#define IDC_PLAYER                      1067
#define IDC_KEY_ROOM                    1068
#define IDC_RADIO7                      1069
#define IDC_RADIO8                      1070
#define IDC_AWAY                        1072
#define IDC_AWAY_REASON                 1073
#define IDC_FILTER                      1074
#define IDC_FIX_NICK                    1075
#define IDC_SECRET_KEY                  1076
#define IDC_BUTTON42                    1077
#define IDC_BUTTON43                    1078
#define IDC_SERVER2                     1079
#define IDC_BUTTON45                    1080
#define IDC_CDKEY                       1081
#define IDC_BUTTON46                    1082
#define IDC_BUTTON47                    1083
#define IDC_BUTTON48                    1084
#define IDC_MAX_PLAYERS                 1088
#define IDC_AUTO_MATCH_STATUS           1089
#define IDC_LOCAL_INFO                  1100
#define IDC_BUTTON40                    1101
#define IDC_START_AUTO_MATCH            1102
#define IDC_STAGING_PLAYERS             1103
#define IDC_GROUP_PLAYERS               1104
#define IDC_BUTTON24                    1105
#define IDC_BUTTON31                    1107
#define IDC_PASSWORD                    1108
#define IDC_NAME                        1109
#define IDC_CHANGE_NICK                 1111
#define IDC_INFO_KEY                    1112
#define IDC_STOP_AUTO_MATCH             1112
#define IDC_KEY                         1113
#define IDC_VALUE                       1114
#define IDC_SERVER                      1115
#define IDC_BUTTON44                    1116

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        134
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1090
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
