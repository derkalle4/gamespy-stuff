#ifndef TYPE_DEFINITIONS_H
#define TYPE_DEFINITIONS_H

//////////////////////////////////////////////////////////////////////////
// Don't need printf in this sample
///Playstation 3 Cell SDK
//#include <spu_printf.h>

#include <stdint.h>
#include <stdlib.h>
#include <string.h> //for memcpy

#endif //TYPE_DEFINITIONS_H
