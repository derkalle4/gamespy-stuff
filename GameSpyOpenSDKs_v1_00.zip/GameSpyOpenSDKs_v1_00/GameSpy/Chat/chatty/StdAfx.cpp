///////////////////////////////////////////////////////////////////////////////
// File:	StdAfx.cpp 
// SDK:		GameSpy Chat SDK
//
// Copyright (c) IGN Entertainment, Inc.  All rights reserved.  
// This software is made available only pursuant to certain license terms offered
// by IGN or its subsidiary GameSpy Industries, Inc.  Unlicensed use or use in a 
// manner not expressly authorized by IGN or GameSpy is prohibited.
// ------------------------------------
// Source file that includes just the standard includes.
// chatty.pch will be the pre-compiled header.
// stdafx.obj will contain the pre-compiled type information.

#include "stdafx.h"

