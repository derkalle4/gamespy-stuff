///////////////////////////////////////////////////////////////////////////////
// File:	Resource.h
// SDK:		GameSpy HTTP SDK
//
// Copyright Notice: This file is part of the GameSpy SDK designed and 
// developed by GameSpy Industries. Copyright (c) 1999-2009 GameSpy Industries, Inc.

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ghttpmfc.rc
//
#define IDD_GHTTPMFC_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDC_URL                         1000
#define IDC_HEADERS                     1001
#define IDC_BLOCKING                    1002
#define IDC_PROGRESS_CALLBACK           1003
#define IDC_COMPLETED_CALLBACK          1004
#define IDC_USER_BUFFER                 1005
#define IDC_GET_FILE                    1006
#define IDC_SAVE_FILE                   1007
#define IDC_STREAM_FILE                 1008
#define IDC_BUFFER_SIZE                 1009
#define IDC_FILE                        1010
#define IDC_SAVE_AS                     1011
#define IDC_SO_FAR                      1012
#define IDC_HEAD_FILE                   1013
#define IDC_HOST_LOOKUP                 1014
#define IDC_RADIO3                      1015
#define IDC_RADIO4                      1016
#define IDC_RADIO5                      1017
#define IDC_RADIO6                      1018
#define IDC_PROGRESS                    1019
#define IDC_THROTTLE                    1020
#define IDC_RADIO7                      1021
#define IDC_RADIO8                      1022
#define IDC_RADIO9                      1023
#define IDC_HEADERS_RECV                1024
#define IDC_STATUS                      1025
#define IDC_POST                        1026
#define IDC_STEP_THINK                  1027
#define IDC_POST_FILE                   1028
#define IDC_POST_OBJECTS                1029
#define IDC_POST_BYTES                  1030
#define IDC_PROXY                       1031
#define IDC_START                       1050
#define IDC_CANCEL                      1051
#define IDC_THINK                       1052
#define IDC_IE_SETTINGS                 1053
#define IDC_SET_PROXY                   1054

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1029
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
