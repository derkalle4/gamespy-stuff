///////////////////////////////////////////////////////////////////////////////
// File:	StdAfx.cpp
// SDK:		GameSpy HTTP SDK
//
// Copyright Notice: This file is part of the GameSpy SDK designed and 
// developed by GameSpy Industries. Copyright (c) 1999-2009 GameSpy Industries, Inc.
// ------------------------------------
// stdafx.cpp : source file that includes just the standard includes
//	ghttpmfc.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"



