Getting gt2testc.c test app to work:

You need 2 computers and put the gt2test.exe executable on both computers:

Listening side
1. Type in the following command: gt2testc.exe -l <local IP>:12345

Connecting side
2. Type in the following command: gt2testc.exe -c <remote IP>:12345 <local IP>:12345