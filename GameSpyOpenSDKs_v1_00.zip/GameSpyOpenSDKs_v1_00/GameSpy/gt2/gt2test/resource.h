///////////////////////////////////////////////////////////////////////////////
// File:	Resource.h
// SDK:		GameSpy Transport 2 SDK
//
// Copyright (c) IGN Entertainment, Inc.  All rights reserved.  
// This software is made available only pursuant to certain license terms offered
// by IGN or its subsidiary GameSpy Industries, Inc.  Unlicensed use or use in a 
// manner not expressly authorized by IGN or GameSpy is prohibited.

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by gt2test.rc
//
#define IDD_GT2TEST_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_ADDRESS_IP                  1000
#define IDC_ADDRESS_PORT                1001
#define IDC_ADDRESS_TO                  1002
#define IDC_ADDRESS_FROM                1003
#define IDC_ADDRESS_STRING              1004
#define IDC_GET_IP_HOST_INFO            1005
#define IDC_GET_STRING_HOST_INFO        1006
#define IDC_ADDRESS_HOSTNAME            1007
#define IDC_CREATE_SOCKET               1008
#define IDC_LOCAL_ADDRESS               1009
#define IDC_ADDRESS_ALIASES             1010
#define IDC_ADDRESS_IPS                 1011
#define IDC_IN_BUFFER_SIZE              1012
#define IDC_OUT_BUFFER_SIZE             1013
#define IDC_CLOSE_SOCKET                1014
#define IDC_THINK                       1015
#define IDC_ALWAYS_THINK                1016
#define IDC_CONNECT                     1017
#define IDC_REMOTE_ADDRESS              1018
#define IDC_BLOCKING                    1019
#define IDC_CLOSE_ALL_CONNECTIONS       1020
#define IDC_CLOSE_ALL_CONNECTIONS_HARD  1021
#define IDC_LISTEN                      1022
#define IDC_ACCEPT_ALL                  1023
#define IDC_REJECT_ALL                  1024
#define IDC_PROMPT                      1025
#define IDC_REJECT_REASON               1026
#define IDC_CONNECTIONS                 1027
#define IDC_CONNECTING                  1028
#define IDC_CONNECTED                   1029
#define IDC_CLOSING                     1030
#define IDC_CLOSED                      1031
#define IDC_MESSAGES                    1032
#define IDC_RELIABLE                    1033
#define IDC_SEND                        1034
#define IDC_MESSAGE                     1035
#define IDC_PING                        1036
#define IDC_CLOSE_CONNECTION_HARD       1037
#define IDC_CONNECT_MESSAGE             1038
#define IDC_SEND_DROP_VALUE             1039
#define IDC_CLOSE_CONNECTION            1040
#define IDC_SEND_ROT13                  1041
#define IDC_SEND_DELAY_VALUE            1042
#define IDC_RECEIVE_DROP_VALUE          1043
#define IDC_RECEIVE_DELAY_VALUE         1044
#define IDC_SEND_DROP                   1045
#define IDC_SEND_DELAY                  1046
#define IDC_RECEIVE_ROT13               1047
#define IDC_RECEIVE_DROP                1048
#define IDC_RECEIVE_DELAY               1049
#define IDC_TIMEOUT                     1050
#define IDC_LIST1                       1051
#define IDC_INCOMING_BUFFER_PROGRESS    1054
#define IDC_INCOMING_BUFFER_SIZE        1055
#define IDC_OUTGOING_BUFFER_PROGRESS    1056
#define IDC_OUTGOING_BUFFER_SIZE        1057

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1058
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
