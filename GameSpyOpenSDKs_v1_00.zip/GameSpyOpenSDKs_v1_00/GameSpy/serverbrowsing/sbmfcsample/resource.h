///////////////////////////////////////////////////////////////////////////////
// File:	Resource.h
// SDK:		GameSpy Server Browsing SDK
//
// Copyright (c) IGN Entertainment, Inc.  All rights reserved.  
// This software is made available only pursuant to certain license terms offered
// by IGN or its subsidiary GameSpy Industries, Inc.  Unlicensed use or use in a 
// manner not expressly authorized by IGN or GameSpy is prohibited.

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by sbmfcsample.rc
//
#define IDD_SBMFCSAMPLE_DIALOG          102
#define IDR_MAINFRAME                   128
#define IDC_SERVERLIST                  1001
#define IDC_REFRESH                     1002
#define IDC_PLAYERLIST                  1003
#define IDC_GAMENAME                    1004
#define IDC_FILTER                      1005
#define IDC_INTERNET                    1006
#define IDC_LAN                         1007
#define IDC_STARTP                      1008
#define IDC_ENDP                        1009
#define IDC_GOA                         1010
#define IDC_QR2                         1011
#define IDC_PROGRESS                    1012
#define IDC_SERVERS                     1013
#define IDC_PLAYERS                     1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
